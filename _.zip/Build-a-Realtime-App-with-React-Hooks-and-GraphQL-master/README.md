## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/build-a-realtime-app-with-react-hooks-and-graphql-video/9781839212970)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Build-a-Realtime-App-with-React-Hooks-and-GraphQL
Code Repository for Build a Realtime App with React Hooks and GraphQL, published by Packt
